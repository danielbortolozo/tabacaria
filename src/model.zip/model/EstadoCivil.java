/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author root
 */
public enum EstadoCivil {
    
    SOLTEIRO,
    CASADO,
    UNIAO_ESTAVEL,
    AMASIADO,
    VIUVO
    
    
    
    
}
